class Entrant < ActiveRecord::Base
  belongs_to :course
end
