class Default < ActiveRecord::Base
end
