CREATE TABLE courses (
  id serial,
  name text
);

