drop table courses;
drop sequence courses_seq;
